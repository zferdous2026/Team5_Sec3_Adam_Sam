library(shiny)
library(dplyr)
library(ggplot2)

data <- read.csv("ai_job_impact.csv", check.names = FALSE) %>%
  rename(Productivity_Change_Pct = `Productivity_Change_%`) %>%
  mutate(
    AI_Adoption_Level = factor(AI_Adoption_Level, levels = c("Low", "Medium", "High")),
    Job_Status = factor(Job_Status, levels = c("Unchanged", "Modified", "Replaced")),
    Salary_Change_Pct = round((Salary_After_AI - Salary_Before_AI) / Salary_Before_AI * 100, 2)
  )

industries <- c("All", sort(unique(data$Industry)))
adoption_colors <- c(Low = "#0072B2", Medium = "#D55E00", High = "#009E73")
status_colors <- c(Unchanged = "#0072B2", Modified = "#E69F00", Replaced = "#333333")
plot_theme <- theme_minimal(base_size = 17) +
  theme(panel.grid = element_blank(), axis.title = element_text(face = "bold"),
        axis.text = element_text(color = "#252525"), axis.line = element_line(color = "#555555"),
        legend.position = "bottom")

# Keep one cumulative count per deployment. Use a shared persistent path if deploying multiple workers.
visits_path <- Sys.getenv("AI_JOBS_VISITS_FILE", file.path(getwd(), "app-visits.sqlite"))
record_visit <- function() {
  con <- DBI::dbConnect(RSQLite::SQLite(), visits_path)
  on.exit(DBI::dbDisconnect(con))
  DBI::dbExecute(con, "PRAGMA busy_timeout = 5000")
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS visits (id INTEGER PRIMARY KEY, total INTEGER NOT NULL)")
  DBI::dbWithTransaction(con, {
    DBI::dbExecute(con, "INSERT OR IGNORE INTO visits VALUES (1, 0)")
    DBI::dbExecute(con, "UPDATE visits SET total = total + 1 WHERE id = 1")
    DBI::dbGetQuery(con, "SELECT total FROM visits WHERE id = 1")$total
  })
}

profile <- function(name, photo, year, degree, minors = NULL) {
  column(6, class = "profile",
    img(src = photo, alt = paste("Headshot of", name)),
    h4(name),
    p(paste("Washington and Lee University", year)),
    p(degree),
    if (!is.null(minors)) p(minors))
}

chart_notes <- function(id) {
  div(class = "chart-notes", textOutput(paste0("finding", id)),
      textOutput(paste0("test", id)))
}

ui <- navbarPage(
  "How Is AI Changing Jobs?",
  header = tags$head(tags$style(HTML("
    body { font-size: 16px; color: #252525; }
    .chart-notes { margin: 14px 0 24px; padding: 12px 16px; background: #f2f6fa; }
    .chart-notes .shiny-text-output + .shiny-text-output { margin-top: 8px; }
    .profile { margin-bottom: 20px; }
    .profile img { width: 140px; height: 175px; object-fit: cover; object-position: center 28%; border-radius: 6px; }
    .table-scroll { overflow-x: auto; }
    .visits { font-weight: 600; margin-bottom: 18px; }
  "))),
  tabPanel("Home",
    h3("Our question"),
    p("How does AI adoption at work relate to salaries, productivity, and whether jobs are kept, changed, or replaced?"),
    p(sprintf("Explore %s employee records across %s industries and %s job roles.",
      format(nrow(data), big.mark = ","), n_distinct(data$Industry), n_distinct(data$Job_Role))),
    div(class = "visits", textOutput("visits")),
    h3("How to use this app"),
    p("Use the tabs to compare salary, productivity, and job status. Where an industry filter is available, the chart and its notes update together."),
    h3("Why this matters to me"),
    p(strong("Samuel Tignor"), br(), "As a pre-med student, I wanted to build awareness of how AI is showing up in workplaces across industries, including healthcare. I've heard people say they'd never use AI in medicine. That made me want to ask a more practical question: Which parts of the job might change, and what should I understand about those tools before I start working with patients?"),
    h3("Team"),
    fluidRow(
      profile("Samuel Tignor", "samuel-tignor.jpeg", 2028, "Biology B.S."),
      profile("Adem Khelifi", "adem-khelifi.jpg", 2027, "Mathematics B.A.",
              "Minors: Computer Science & Data Science"))
  ),
  tabPanel("Salary",
    h3("Salary change by AI adoption level"),
    selectInput("industry1", "Choose an industry:", choices = industries),
    plotOutput("graph1"), chart_notes(1)
  ),
  tabPanel("Before vs After",
    h3("Salary before vs after AI"),
    selectInput("industry2", "Choose an industry:", choices = industries),
    plotOutput("graph2"), chart_notes(2)
  ),
  tabPanel("Job Status",
    h3("Job status by industry"),
    plotOutput("graph3", height = "460px"), chart_notes(3)
  ),
  tabPanel("Productivity",
    h3("Productivity change by AI adoption level"),
    selectInput("industry4", "Choose an industry:", choices = industries),
    plotOutput("graph4"), chart_notes(4)
  ),
  tabPanel("Job Roles",
    h3("Average salary change by job role"),
    plotOutput("graph5", height = "680px"), chart_notes(5)
  ),
  tabPanel("Summary",
    h3("Summary by AI adoption level"),
    div(class = "table-scroll", tableOutput("summary_table")),
    p("This table shows counts and averages. The Salary and Productivity tabs report the corresponding tests across adoption levels.")
  ),
  tabPanel("Data",
    h3("First 20 rows"),
    p("This preview shows the first 20 records. The chart notes use all eligible records for the selected view."),
    div(class = "table-scroll", tableOutput("data_table"))
  ),
  tabPanel("Acknowledgments",
    h3("Dataset"),
    p("The analyses use ai_job_impact.csv. The original publisher and how the data were collected are unverified."),
    h3("Instructor"),
    p("Thank you to Professor Zannatul Ferdous for her guidance and support on this project."),
    h3("Reading the statistical notes"),
    p("The notes use a 0.05 significance threshold for each exploratory test. The p-values are unadjusted for multiple comparisons. Group tests look for evidence of a difference somewhere across the groups. The results describe patterns in this dataset, and the study design and sampling would need to be verified before drawing conclusions about causation or broader workplace trends.")
  )
)

test_note <- function(test, explanation) {
  result <- tryCatch(force(test), error = function(e) NULL)
  if (is.null(result) || !is.finite(result$p.value)) {
    return("Statistical test unavailable for these data.")
  }
  p <- result$p.value
  conclusion <- if (p < 0.05) {
    "The difference is statistically significant at the 0.05 level."
  } else {
    "The test did not find a statistically significant difference at the 0.05 level."
  }
  p_label <- if (p < 0.001) "p < 0.001" else paste("p =", format(signif(p, 5), scientific = FALSE, trim = TRUE))
  paste0(explanation, " (", p_label, "). ", conclusion)
}

mean_by_adoption <- function(rows, variable) {
  means <- rows %>%
    filter(!is.na(AI_Adoption_Level), is.finite(.data[[variable]])) %>%
    group_by(AI_Adoption_Level) %>%
    summarise(value = mean(.data[[variable]]), .groups = "drop")
  if (nrow(means) == 0) return("No values available.")
  paste(sprintf("%s %+.1f%%", means$AI_Adoption_Level, means$value), collapse = ", ")
}

server <- function(input, output) {
  visit_total <- tryCatch(record_visit(), error = function(e) {
    warning(conditionMessage(e))
    NA_integer_
  })
  output$visits <- renderText({
    if (is.na(visit_total)) "Total app visits unavailable"
    else paste("Total app visits", format(visit_total, big.mark = ","), sep = ": ")
  })

  pick_industry <- function(choice) {
    req(choice)
    if (choice == "All") data else filter(data, Industry == choice)
  }
  salary_rows <- reactive(pick_industry(input$industry1))
  paired_rows <- reactive(pick_industry(input$industry2))
  productivity_rows <- reactive(pick_industry(input$industry4))

  output$graph1 <- renderPlot({
    ggplot(salary_rows(), aes(AI_Adoption_Level, Salary_Change_Pct, fill = AI_Adoption_Level)) +
      geom_boxplot(show.legend = FALSE) +
      scale_fill_manual(values = adoption_colors) +
      labs(x = "AI adoption level", y = "Salary change (%)") + plot_theme
  })
  output$finding1 <- renderText({
    paste0("Average salary change: ", mean_by_adoption(salary_rows(), "Salary_Change_Pct"), ".")
  })
  output$test1 <- renderText({
    test_note(kruskal.test(Salary_Change_Pct ~ AI_Adoption_Level, data = salary_rows()),
              "Kruskal–Wallis test comparing salary changes across AI adoption levels")
  })

  output$graph2 <- renderPlot({
    ggplot(paired_rows(), aes(Salary_Before_AI, Salary_After_AI,
                             color = AI_Adoption_Level, shape = AI_Adoption_Level)) +
      geom_point(alpha = 0.55) +
      geom_abline(slope = 1, intercept = 0, linetype = "dashed") +
      scale_color_manual(values = adoption_colors) +
      labs(x = "Salary before AI ($)", y = "Salary after AI ($)",
           color = "AI adoption", shape = "AI adoption") + plot_theme
  })
  output$finding2 <- renderText({
    rows <- paired_rows()
    changes <- with(rows, Salary_After_AI - Salary_Before_AI)
    sprintf("Points above the dashed line earned more after AI. In this view, %.1f%% did.",
            100 * mean(changes > 0, na.rm = TRUE))
  })
  output$test2 <- renderText({
    rows <- paired_rows()
    test_note(t.test(rows$Salary_After_AI, rows$Salary_Before_AI, paired = TRUE),
              "Paired t-test comparing each employee's salary before and after AI")
  })

  output$graph3 <- renderPlot({
    ggplot(data, aes(Industry, fill = Job_Status)) +
      geom_bar(position = "fill", color = "white", linewidth = 0.3) +
      scale_fill_manual(values = status_colors) +
      scale_y_continuous(labels = function(x) paste0(100 * x, "%")) +
      labs(x = NULL, y = "Share of employees", fill = "Job status") + plot_theme +
      theme(axis.text.x = element_text(angle = 30, hjust = 1))
  })
  output$finding3 <- renderText({
    shares <- data %>% filter(!is.na(Job_Status)) %>% group_by(Industry) %>%
      summarise(share = mean(Job_Status != "Unchanged"), .groups = "drop") %>%
      arrange(desc(share))
    last <- nrow(shares)
    sprintf("The highest share of modified or replaced jobs was in %s (%.1f%%). The lowest was in %s (%.1f%%).",
            shares$Industry[1], 100 * shares$share[1], shares$Industry[last], 100 * shares$share[last])
  })
  output$test3 <- renderText({
    test_note(chisq.test(table(data$Industry, data$Job_Status)),
              "Chi-square test comparing job status across industries")
  })

  output$graph4 <- renderPlot({
    ggplot(productivity_rows(), aes(AI_Adoption_Level, Productivity_Change_Pct,
                                    fill = AI_Adoption_Level)) +
      geom_boxplot(show.legend = FALSE) +
      scale_fill_manual(values = adoption_colors) +
      labs(x = "AI adoption level", y = "Productivity change (%)") + plot_theme
  })
  output$finding4 <- renderText({
    paste0("Average productivity change: ",
           mean_by_adoption(productivity_rows(), "Productivity_Change_Pct"), ".")
  })
  output$test4 <- renderText({
    test_note(kruskal.test(Productivity_Change_Pct ~ AI_Adoption_Level, data = productivity_rows()),
              "Kruskal–Wallis test comparing productivity changes across AI adoption levels")
  })

  role_means <- data %>% group_by(Job_Role) %>%
    summarise(avg_change = mean(Salary_Change_Pct, na.rm = TRUE), .groups = "drop") %>%
    arrange(desc(avg_change))

  output$graph5 <- renderPlot({
    ggplot(role_means, aes(reorder(Job_Role, avg_change), avg_change)) +
      geom_col(fill = "#0072B2") + coord_flip() +
      labs(x = NULL, y = "Average salary change (%)") + plot_theme
  })
  output$finding5 <- renderText({
    last <- nrow(role_means)
    sprintf("%s had the highest average salary change (%+.1f%%), and %s had the lowest (%+.1f%%).",
            role_means$Job_Role[1], role_means$avg_change[1],
            role_means$Job_Role[last], role_means$avg_change[last])
  })
  output$test5 <- renderText({
    test_note(kruskal.test(Salary_Change_Pct ~ Job_Role, data = data),
              "Kruskal–Wallis test comparing salary changes across job roles")
  })

  output$summary_table <- renderTable({
    data %>% group_by(AI_Adoption_Level) %>%
      summarise(
        Employees = n(),
        `Avg salary change (%)` = mean(Salary_Change_Pct),
        `Avg productivity (%)` = mean(Productivity_Change_Pct),
        `Avg satisfaction` = mean(Job_Satisfaction),
        .groups = "drop"
      )
  })

  output$data_table <- renderTable(head(data, 20))
}

shinyApp(ui = ui, server = server)
